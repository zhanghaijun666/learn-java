package decorate;

/**
 * 手机接口
 * @author think
 *
 */
public interface PhoneInterface {
	void call();
}
