package adapter.adaptee;

public class ZGSocketImpl implements ZGSocket {

	@Override
	public void method() {
		System.out.println("中国插座使用三眼插孔");
	}

}
