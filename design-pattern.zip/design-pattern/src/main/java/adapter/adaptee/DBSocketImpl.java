package adapter.adaptee;

public class DBSocketImpl implements DBSocket {

	@Override
	public void method() {
		System.out.println("德国插座是使用两个眼的");
	}

}
