package adapter.adaptee;

public interface ZGSocket {

	public void method();
}
